package buy.service.login;

import buy.domain.User;

public interface Login {
	
	public User findUser(String name);

}

package buy.domain;

public class Role {
	private String id;
	private String name;
	private Source[] source;

}
